# AFERNANDEZ_ms_2024
Calculo de posición con IMU9
